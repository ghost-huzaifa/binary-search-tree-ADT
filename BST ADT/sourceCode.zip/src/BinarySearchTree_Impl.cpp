#include "BinarySearchTree.cpp"
#include <string>

using namespace std;

template class BinarySearchTree<int>;
template class BinarySearchTree<float>;
template class BinarySearchTree<double>;
template class BinarySearchTree<char>;
template class BinarySearchTree<string>;
template class BinarySearchTree<short>;
template class BinarySearchTree<long>;

